# NewsBot
To work with this bot, you should have python inst


## Installation

1. Create a virtual environment (optional but recommended):
   ```
   python -m venv venv
   source venv/bin/activate   # On Windows: venv\Scripts\activate
   ```

2. (Upcoming, till then ypu have to manually install all the depedencies)Install project dependencies from `requirements.txt`:
   ```bash
   pip install -r requirements.txt
   ```

## Running the App

1. Start the Telegram bot server:
   ```
   python bot.py
   ```

2. The bot should start working now.

## Usage

1. Open telegram app and you can start working with the bot.

2. Use the commands provided by bot to get the news.
   
