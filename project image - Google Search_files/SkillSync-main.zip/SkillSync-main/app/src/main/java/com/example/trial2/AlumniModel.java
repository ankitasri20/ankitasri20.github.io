package com.example.trial2;

public class AlumniModel {
    int a_id;
    String a_name;
    String a_email;
    String a_contact;
    String a_skill;
    String a_description;
    String a_gender;

    public AlumniModel(int a_id, String a_name, String a_email, String a_contact, String a_skill, String a_description, String a_gender) {
        this.a_id = a_id;
        this.a_name = a_name;
        this.a_email = a_email;
        this.a_contact = a_contact;
        this.a_skill = a_skill;
        this.a_description = a_description;
        this.a_gender = a_gender;
    }
}
