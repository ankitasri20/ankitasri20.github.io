package com.example.trial2.model;

public class alumniDetail {
    int img;
    String a_name, a_description;

    public alumniDetail(int img, String a_name, String a_description) {
        this.img = img;
        this.a_name = a_name;
        this.a_description = a_description;
    }
}
